<?php
/**
 * Main Pintar - Konfigurasi LOKAL (jangan di-commit).
 * Templatennya: includes/config.local.example.php
 */

define('DB_HOST', 'sql312.infinityfree.com');
define('DB_NAME', 'if0_41894075_kuis');
define('DB_USER', 'if0_41894075');
define('DB_PASS', 'br5awqzeax3pPwn');
